import React from 'react';
import { View, Text } from 'react-native';

const LibraryScreen = () => {
    return (
        <View>
            <Text>Library Screen</Text>
        </View>
    );
};

export default LibraryScreen;