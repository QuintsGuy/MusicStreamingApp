import React from 'react';
import { View, Text } from 'react-native';

const PlaylistScreen = () => {
    return (
        <View>
            <Text>Playlist Screen</Text>
        </View>
    );
};

export default PlaylistScreen;