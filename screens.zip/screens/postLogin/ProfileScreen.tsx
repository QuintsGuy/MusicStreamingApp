import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, Image, Alert, Keyboard } from 'react-native';
import supabase from '../../services/supabase';
import * as ImagePicker from 'expo-image-picker';
import Icon from 'react-native-vector-icons/Ionicons';

type Profile = {
    avatar_url: string | null;
    displayName: string | null;
    username: string | null;
    bio: string | null;
    phone: string | null;
};

const ProfileScreen = () => {
    const [profile, setProfile] = useState<Profile>({
        avatar_url: null,
        displayName: null,
        username: null,
        bio: null,
        phone: null,
    });

    const [editField, setEditField] = useState<string | null>(null);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        fetchProfile();
    }, []);

    const fetchProfile = async () => {
        try {
            setLoading(true);
            const { data: { user }, error: userError } = await supabase.auth.getUser();
            
            if (userError || !user) throw userError;

            const { data, error } = await supabase
                .from('profiles')
                .select('avatar_url, full_name, username, bio, phone')
                .eq('id', user.id)
                .single();

            if (error) throw error;

            setProfile({
                avatar_url: data.avatar_url,
                displayName: data.full_name,
                username: data.username,
                bio: data.bio,
                phone: data.phone,
            });

        } catch (error) {
            Alert.alert('Error', 'Failed to load profile information');
        } finally {
            setLoading(false);
        }
    };

    const handleSaveChanges = async () => {
        try {
            await updateProfile({
                displayName: profile.displayName,
                username: profile.username,
                bio: profile.bio,
                phone: profile.phone,
            });
        } catch (error) {
            console.error(error);
            Alert.alert('Error', 'Failed to save changes.');
        }
    };

    const handleEditField = (field: string) => {
        if (editField === field) return;
        setEditField(field);
    };

    const handleFocusOut = (field: string) => {
        Keyboard.dismiss();
        Alert.alert(
            'Confirm Changes',
            'Would you like to save the changes?',
            [
                {
                    text: 'Cancel',
                    onPress: () => {
                        setEditField(null);
                        fetchProfile();
                    },
                    style: 'cancel',
                },
                {
                    text: 'Save',
                    onPress: () => {
                        handleSaveChanges();
                        setEditField(null);
                    },
                },
            ]
        );
    };

    const renderProfileField = (field: keyof Profile, placeholder: string, isMultiline = false) => (
        <View style={styles.profileItem}>
            {editField === field ? (
                <TextInput
                    style={[styles.input, isMultiline ? styles.bioInput : null]}
                    value={profile[field] || ''}
                    onChangeText={(text) => setProfile({ ...profile, [field]: text })}
                    onBlur={() => handleFocusOut(field)}
                    autoFocus
                    multiline={isMultiline}
                />
            ) : (
                <View style={styles.textRow}>
                    <Text style={styles.textLabel}>{profile[field] || placeholder}</Text>
                    <TouchableOpacity onPress={() => handleEditField(field)}>
                        <Icon name="pencil" size={20} color="#1DB954" />
                    </TouchableOpacity>
                </View>
            )}
        </View>
    );

    const handleImageUpload = async () => {
        const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (status !== 'granted') {
            Alert.alert('Permission Denied', 'We need camera roll permissions to upload a profile picture.');
            return;
        }

        let result = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images,
            allowsEditing: true,
            aspect: [1, 1],
            quality: 1,
        });

        if (!result.canceled) {
            const file = result.assets[0];
            await uploadImage(file.uri);
        }
    };

    const uploadImage = async (uri: string) => {
        try {
            const { data: { user } } = await supabase.auth.getUser();
            if (!user) throw new Error('User not found');
    
            const response = await fetch(uri);
            const blob = await response.blob();
    
            const fileExt = uri.split('.').pop();
            const fileName = `${user.id}.${fileExt}`;
            const filePath = `avatars/${fileName}`;
    
            const { error: uploadError } = await supabase.storage
                .from('avatars')
                .upload(filePath, blob, { upsert: true });
    
            if (uploadError) throw uploadError;
    
            const { data: { publicUrl } } = supabase
                .storage
                .from('avatars')
                .getPublicUrl(filePath);
    
            if (!publicUrl) throw new Error('No public URL found');
    
            await updateProfile({ avatar_url: publicUrl });
            Alert.alert('Success', 'Profile picture updated successfully!');
        } catch (error) {
            console.error('Upload image error:', error);
            Alert.alert('Error', 'Failed to upload image.');
        }
    };

    const updateProfile = async (updates: Partial<Profile>) => {
        try {
            const { data: { user }, error: userError } = await supabase.auth.getUser();
            if (userError || !user) throw userError;

            const { data, error } = await supabase
                .from('profiles')
                .update(updates)
                .eq('id', user.id);

            if (error) throw error;

            fetchProfile();
            Alert.alert('Success', 'Profile updated successfully!');
        } catch (error) {
            Alert.alert('Error', 'Failed to update profile.');
        }
    };

    const handleChangePassword = () => {
        // Implement password change logic here
        Alert.alert('Change Password', 'Password change functionality not implemented yet.');
    };

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Profile</Text>

            <TouchableOpacity style={styles.imageUpload} onPress={handleImageUpload}>
                {profile.avatar_url ? (
                    <Image source={{ uri: profile.avatar_url }} style={styles.profileImage} />
                ) : (
                    <View style={[styles.profileImage, styles.defaultAvatar]}>
                        <Icon name="person" size={50} color="#ffffff" />
                    </View>
                )}
                <Text style={styles.uploadText}>Upload Profile Picture</Text>
            </TouchableOpacity>

            {renderProfileField('displayName', 'Display Name')}
            {renderProfileField('username', 'Username')}
            {renderProfileField('bio', 'Bio', true)}
            {renderProfileField('phone', 'Phone Number')}

            <TouchableOpacity style={styles.button} onPress={handleChangePassword}>
                <Text>Change Password</Text>
            </TouchableOpacity>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        backgroundColor: '#121212',
        alignItems: 'center',
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 20,
        color: 'white',
    },
    imageUpload: {
        alignItems: 'center',
        marginBottom: 20,
    },
    profileImage: {
        width: 100,
        height: 100,
        borderRadius: 50,
        marginBottom: 10,
    },
    uploadText: {
        color: '#1DB954',
    },
    profileItem: {
        width: '100%',
        marginBottom: 15,
    },
    textRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        borderBottomWidth: 1,
        borderBottomColor: 'gray',
    },
    textLabel: {
        fontSize: 18,
        color: 'white',
    },
    input: {
        color: 'white',
        backgroundColor: '#333',
        padding: 10,
        borderRadius: 5,
    },
    bioInput: {
        height: 80,
        textAlignVertical: 'top',
    },
    button: {
        backgroundColor: '#1DB954',
        padding: 10,
        borderRadius: 5,
        marginBottom: 10,
    },
    defaultAvatar: {
        backgroundColor: '#ccc',
        justifyContent: 'center',
        alignItems: 'center',
    },
});

export default ProfileScreen;