import React from 'react';
import { View, Text } from 'react-native';

const SearchScreen = () => {
    return (
        <View>
            <Text>Search Screen</Text>
        </View>
    );
};

export default SearchScreen;